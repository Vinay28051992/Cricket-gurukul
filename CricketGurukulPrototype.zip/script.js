document.addEventListener("DOMContentLoaded", function () {
    const callButtons = document.querySelectorAll(".call-btn");
    const shareButtons = document.querySelectorAll(".share-btn");

    callButtons.forEach(button => {
        button.addEventListener("click", () => {
            alert("Calling the player...");
        });
    });

    shareButtons.forEach(button => {
        button.addEventListener("click", () => {
            alert("Sharing player profile...");
        });
    });
});
